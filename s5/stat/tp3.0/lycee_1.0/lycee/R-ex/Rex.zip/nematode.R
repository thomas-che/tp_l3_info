### Encoding: ISO-8859-1

### Name: nematode
### Title: nematode/m�dicale
### Aliases: nematode


### ** Examples

data(nematode)
lire(nematode)
histogramme(long)
boitemoustache(long)
mediane(long)
moyenne(long)




