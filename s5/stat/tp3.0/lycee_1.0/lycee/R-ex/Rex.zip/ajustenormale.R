### Encoding: ISO-8859-1

### Name: ajustenormale
### Title: Fonction qui trace l'histogramme et la densit� de la loi
###   normale.
### Aliases: ajustenormale


### ** Examples

data(avion)
lire(avion)
tauxannulation=annulation/reservation
histogramme(tauxannulation)
ajustenormale(tauxannulation)
data(QI)
lire(QI)
histogramme(Qintellectuel)
ajustenormale(Qintellectuel)



