### Encoding: ISO-8859-1

### Name: simulenormale
### Title: Function qui simule une distribution normale et trace son
###   histogramme.
### Aliases: simulenormale


### ** Examples

simulenormale(1000,4,1)




