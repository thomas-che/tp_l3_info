### Encoding: ISO-8859-1

### Name: regression
### Title: Fonction qui calcul la droite de r�gression d'un nuage de points
###   et trace le graphique.
### Aliases: regression


### ** Examples

data(bebe)
lire(bebe)
regression(long,poids)


