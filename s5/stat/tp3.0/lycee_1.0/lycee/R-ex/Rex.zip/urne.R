### Encoding: ISO-8859-1

### Name: urne
### Title: Fonction qui construit une urne contenant des boules. Chacune
###   peut-�tre bleue, noire ou verte.
### Aliases: urne


### ** Examples

u<-urne(100000,40000,500000)
t<-tirage(1000,u)
frequence(t)
diagrammeenbarre(t)
camembert(t)




