### Encoding: ISO-8859-1

### Name: guichet
### Title: guichet/ donn�es de nature �conomique
### Aliases: guichet


### ** Examples

data(guichet)
lire(guichet)
diagrammeenbarre(queue)
camembert(queue)
frequence(queue)
mediane(queue)
boitemoustache(queue)



