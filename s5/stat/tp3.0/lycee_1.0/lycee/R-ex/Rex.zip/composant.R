### Encoding: ISO-8859-1

### Name: composant
### Title: composant/contr�le qualit�.
### Aliases: composant


### ** Examples

data(composant)
lire(composant)
histogramme(vie)
ajusteexponentielle(vie)




