### Encoding: ISO-8859-1

### Name: vecteur
### Title: Fonction qui cr�e un vecteur � partie de 2 vecteurs ou 2
###   nombres.
### Aliases: vecteur


### ** Examples

c=vecteur(3,4)
v=vecteur(c,2)




