### Encoding: ISO-8859-1

### Name: boitesparalleles
### Title: Fonction qui trace sur le m�me graphique diff�rentes boites �
###   moustaches .
### Aliases: boitesparalleles


### ** Examples


data(bebe)
lire(bebe)
boitesparalleles(poids,sexe)


