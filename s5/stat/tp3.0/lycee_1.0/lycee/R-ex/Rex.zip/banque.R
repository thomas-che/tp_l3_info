### Encoding: ISO-8859-1

### Name: banque
### Title: banque /donn�es banquaires
### Aliases: banque


### ** Examples

data(banque)
lire(banque)
camembert(credcon)
diagrammeenbarre(age)




