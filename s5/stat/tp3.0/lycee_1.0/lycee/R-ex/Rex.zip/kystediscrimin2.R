### Encoding: ISO-8859-1

### Name: kystediscrimin2
### Title: Aide au diagnostique de kystes ovariens /type m�dical
### Aliases: kystediscrimin2


### ** Examples

data(kystediscrimin2)
lire (kystediscrimin2)
nuagedepoints(discr1,discr2,color)



