### Encoding: ISO-8859-1

### Name: boitemoustache
### Title: Fonction qui trace la boite � moustache
### Aliases: boitemoustache


### ** Examples

d<-jeudedes(100)
boitemoustache(d)
data(bebe)
lire(bebe)
boitemoustache(long)
mediane(long)


