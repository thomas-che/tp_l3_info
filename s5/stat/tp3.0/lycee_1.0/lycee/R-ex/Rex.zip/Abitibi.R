### Encoding: ISO-8859-1

### Name: Abitibi
### Title: Abitibi/donn�es g�ochimiques
### Aliases: Abitibi


### ** Examples
data(Abitibi)
lire(Abitibi)
hist(Al2O3)
mean(FeO)
mediane(MgO)
boitesparalleles(CaO,G)
histogramme(selection(Al2O3,G,"g"))



