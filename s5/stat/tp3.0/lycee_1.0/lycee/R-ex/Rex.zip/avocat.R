### Encoding: ISO-8859-1

### Name: avocat
### Title: avocat/donn�es de nature �conomique
### Aliases: avocat


### ** Examples

data(avocat)
lire(avocat)
histogramme(revenu)
boitemoustache(revenu)
mediane(revenu)
moyenne(revenu)



