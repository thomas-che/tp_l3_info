### Encoding: ISO-8859-1

### Name: publicite
### Title: influence du budget publicit�/marketting
### Aliases: publicite


### ** Examples

data(publicite)
lire(publicite)
regression(budgetpub,vente)



