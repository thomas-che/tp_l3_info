### Encoding: ISO-8859-1

### Name: urbanisme
### Title: urbanisation/d�mographique
### Aliases: urbanisme


### ** Examples

data(urbanisme)
lire(urbanisme)
nuagedepoints(tauxnatalite,tauxurbanisation,'red')




