### Encoding: ISO-8859-1

### Name: simuleexponentielle
### Title: Function qui simule une distribution exponentielle et trace son
###   histogramme.
### Aliases: simuleexponentielle


### ** Examples

simuleexponentielle(1000,1/4)




