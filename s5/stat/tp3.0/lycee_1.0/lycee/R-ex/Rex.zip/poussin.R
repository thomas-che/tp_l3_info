### Encoding: ISO-8859-1

### Name: poussin
### Title: poussin/�levage
### Aliases: poussin
### Keywords: datasets

### ** Examples

data(poussin)
lire(poussin)
selection(poidsg,r�gime,1)
couleur=ifelse(r�gime=='1','red',ifelse(r�gime=='2','green','orange'))
nuagedepoints(agej,poidsg,couleur)



