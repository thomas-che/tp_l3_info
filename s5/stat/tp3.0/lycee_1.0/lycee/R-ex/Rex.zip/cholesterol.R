### Encoding: ISO-8859-1

### Name: cholesterol
### Title: cholesterol/donn�es de type m�dical.
### Aliases: cholesterol


### ** Examples

data(cholesterol)
lire(cholesterol)
hist(taux)
mean(taux)
mediane(taux)
boitesparalleles(taux,fumeur)
histogramme(selection(taux,fumeur,"oui"))



