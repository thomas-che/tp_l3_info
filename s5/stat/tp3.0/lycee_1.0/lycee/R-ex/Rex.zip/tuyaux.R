### Encoding: ISO-8859-1

### Name: tuyaux
### Title: tuyaux/controle qualit�
### Aliases: tuyaux


### ** Examples

data(tuyaux)
lire(tuyaux)
boitesparalleles(corrosion,sol)



