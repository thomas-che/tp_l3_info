### Encoding: ISO-8859-1

### Name: jeudedes
### Title: Fonction qui simule le lancer d'un d�s r�gulier.
### Aliases: jeudedes


### ** Examples

d<-jeudedes(1000)
frequence(d)
diagrammeenbarre(d)
camembert(d)
boitemoustache(d)
mediane(d)



