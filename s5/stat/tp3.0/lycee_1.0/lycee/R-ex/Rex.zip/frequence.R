### Encoding: ISO-8859-1

### Name: frequence
### Title: Fonction qui donne les fr�quences respectives des diff�rentes
###   valeurs observ�es.
### Aliases: frequence


### ** Examples

d<-tpileface(1000,0.7)
d
frequence(d)
d<-jeudedes(1000)
frequence(d)
mediane(d)
boitemoustache(d)
camembert(d)




