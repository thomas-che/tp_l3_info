### Encoding: ISO-8859-1

### Name: avion
### Title: Dossier renseign� de 2000 vols dans une compagnie
###   a�rienne/gestion
### Aliases: avion


### ** Examples

data(avion)
lire(avion)
tauxannulation=annulation/reservation
selection(tauxannulation,butvoyage,"vacances")
boitesparalleles(tauxannulation,butvoyage)



