### Encoding: ISO-8859-1

### Name: nuagedepoints
### Title: Fonction qui trace le nuage de points repr�sentant deux
###   variables quantitatives.
### Aliases: nuagedepoints


### ** Examples

data(urbanisme)
lire(urbanisme)
nuagedepoints(tauxnatalite,tauxurbanisation,'red')
regression(tauxnatalite,tauxurbanisation)
data(kystediscrimin1)
lire(kystediscrimin1)
nuagedepoints(disc1,disc2,coul)




