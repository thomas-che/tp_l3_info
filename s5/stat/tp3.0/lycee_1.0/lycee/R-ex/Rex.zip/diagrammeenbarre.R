### Encoding: ISO-8859-1

### Name: diagrammeenbarre
### Title: Fonction qui trace le diagramme en barre
### Aliases: diagrammeenbarre


### ** Examples

d=pileface(100)
diagrammeenbarre(d)
messagecode=c("U","N","W","E","R", "N","M","N","C","D","N","A","N","B","C","M","N","E","N","W",
 "D","N","C","A","X","Y","O","X","A","C","N","J","D","A","J","R","S","N","U","N","L","X",
"D","A","J","P","N","M","N","U","N","O","J","R","A","N","L","N","U","J","W","N","M","X",
"R","C","Y","J","B","N","C","A","N","M","R","O","O","R","L","R","U","N","M","N","D","G",
"K","J","U","U","N","B","M","J","W","B","U","N","L","X","N","D","A","N","C","L","N","B",
"C","O","R","W","R","R","U","B","D","O","O","R","C","M","J","C","C","N","W","M","A",
"N","D","W","N","E","R","L","C","R","V","N","W","R","V","Y","X","A","C","N","Z","D",
"R","M","N","C","R","A","N","A","N","C","U","N","C","X","D",
"A","N","B","C","S","X","D","N","L","N","B","C","M","N","L","R","M","N","M","N","V","J","R",
"W","S","N","U","N","O","J","R","B")
diagrammeenbarre(messagecode)



