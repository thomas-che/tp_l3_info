### Encoding: ISO-8859-1

### Name: QI
### Title: QI/donn�es de nature psychologique.
### Aliases: QI


### ** Examples

data(QI)
lire(QI)
histogramme(Qintellectuel)
boitemoustache(Qintellectuel)
mediane(Qintellectuel)
moyenne(Qintellectuel)



