### Encoding: ISO-8859-1

### Name: selection
### Title: Fonction qui s�lectionne une partie d'une colonne.
### Aliases: selection


### ** Examples


data(bebe)
lire(bebe)
selection(long,sexe,"fille")


