### Encoding: ISO-8859-1

### Name: soleil
### Title: soleil/donn�es m�t�orologiques.
### Aliases: soleil


### ** Examples

data(soleil)
lire(soleil)
histogramme(Nh)
boitemoustache(Nh)
moyenne(Nh)
mediane(Nh)
ecarttype(Nh)




