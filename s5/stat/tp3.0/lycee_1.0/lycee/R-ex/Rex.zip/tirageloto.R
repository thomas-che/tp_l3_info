### Encoding: ISO-8859-1

### Name: tirageloto
### Title: Fonction qui simule le tirage du loto
### Aliases: tirageloto


### ** Examples

tirageloto(10)



