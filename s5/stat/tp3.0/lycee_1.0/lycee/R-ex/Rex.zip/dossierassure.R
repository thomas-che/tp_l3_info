### Name: dossierassure
### Title: dossier des assur�s/actuariat
### Aliases: dossierassure


### ** Examples

data(dossierassure)
lire(dossierassure)
boitesparalleles(sinis10,gr)



