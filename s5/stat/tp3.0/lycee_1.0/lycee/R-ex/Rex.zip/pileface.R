### Encoding: ISO-8859-1

### Name: pileface
### Title: Fonction qui simule le jeu de pile ou face avec une pi�ce
###   �quilibr�e.
### Aliases: pileface


### ** Examples

d<-pileface(1000)
d
frequence(d)
diagrammeenbarre(d)
camembert(d)



