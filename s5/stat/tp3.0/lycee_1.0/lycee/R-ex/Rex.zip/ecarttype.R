### Encoding: ISO-8859-1

### Name: ecarttype
### Title: Fonction qui donne l'�cart type d'une variable num�rique.
### Aliases: ecarttype


### ** Examples

data(tumeur)
lire(tumeur)
ecarttype(surface)



