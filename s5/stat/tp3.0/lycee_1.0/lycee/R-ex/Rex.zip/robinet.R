### Encoding: ISO-8859-1

### Name: robinet
### Title: robinet/m�dicale
### Aliases: robinet


### ** Examples

data(robinet)
lire(robinet)
histogramme(consommation)
boitemoustache(consommation)
mediane(consommation)
moyenne(consommation)
ecarttype(consommation)
variance(consommation)



