### Encoding: ISO-8859-1

### Name: conte
### Title: conte/texte
### Aliases: conte


### ** Examples

data(conte)
lire(conte)
frequence(texte)



