### Encoding: ISO-8859-1

### Name: revenuetudiant
### Title: revenueetudiant/donn�es �conomiques
### Aliases: revenuetudiant


### ** Examples

data(revenuetudiant)
lire(revenuetudiant)
histogramme(Revenu)
boitemoustache(Revenu)
mediane(Revenu)
moyenne(Revenu)
ecarttype(Revenu)




