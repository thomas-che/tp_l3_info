### Encoding: ISO-8859-1

### Name: population
### Title: Fonction qui construit une population de 1000000 d'individus
###   ayant une opinion oui ou non relativement � un sujet quelconque.
### Aliases: population


### ** Examples

pop<-population(0.2)
s<-sondage(1000,pop)
frequence(s)
diagrammeenbarre(s)
camembert(s)




