### Encoding: ISO-8859-1

### Name: bebe
### Title: bebe/donn�es m�dicales
### Aliases: bebe


### ** Examples
data(bebe) 
lire(bebe)
hist(long)
moyenne(long)
mediane(long)
ecarttype(long)
hist(poids)
boitesparalleles(poids,sexe)



