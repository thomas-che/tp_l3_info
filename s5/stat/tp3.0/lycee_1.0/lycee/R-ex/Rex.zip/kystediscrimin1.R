### Encoding: ISO-8859-1

### Name: kystediscrimin1
### Title: Aide au diagnostique de kystes ovariens /type m�dical
### Aliases: kystediscrimin1


### ** Examples

data(kystediscrimin1)
lire (kystediscrimin1)
nuagedepoints(disc1,disc2,coul)



