### Encoding: ISO-8859-1

### Name: tumeur
### Title: tumeur/donn�es de type biologique
### Aliases: tumeur


### ** Examples

data(tumeur) 
lire(tumeur) 
histogramme(surface)
moyenne(surface)
mediane(surface)
ecarttype(surface)




