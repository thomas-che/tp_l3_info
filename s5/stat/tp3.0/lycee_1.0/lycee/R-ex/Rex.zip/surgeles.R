### Encoding: ISO-8859-1

### Name: surgeles
### Title: surgeles/�tude de march�
### Aliases: surgeles


### ** Examples

data(surgeles)
lire(surgeles)
histogramme(ventes)
boitemoustache(ventes)
mediane(ventes)
moyenne(ventes)
ecarttype(ventes)



