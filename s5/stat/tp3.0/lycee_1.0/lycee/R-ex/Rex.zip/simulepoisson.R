### Encoding: ISO-8859-1

### Name: simulepoisson
### Title: Function qui simule une distribution de poisson et trace son
###   histogramme.
### Aliases: simulepoisson


### ** Examples

simulepoisson(1000,4)





