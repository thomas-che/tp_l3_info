### Encoding: ISO-8859-1

### Name: sondage
### Title: Fonction qui pr�l�ve al�atoirement un �chantillon dans une
###   population.
### Aliases: sondage


### ** Examples

pop<-population(0.7)
s<-sondage(100,pop)
frequence(s)
frequence(sondage(100,tpileface(10000,0.6)))




