### Encoding: ISO-8859-1

### Name: tpileface
### Title: Fonction qui simule le jeu de pile ou face avec une pi�ce
###   truqu�e
### Aliases: tpileface


### ** Examples

d<-tpileface(100, 0.7)
diagrammeenbarre(d)
frequence(d)



