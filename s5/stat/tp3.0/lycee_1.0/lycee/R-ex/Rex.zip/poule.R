### Encoding: ISO-8859-1

### Name: poule
### Title: poule/�levage
### Aliases: poule


### ** Examples

data(poule)
lire(poule)
regression(oeufs,age)



