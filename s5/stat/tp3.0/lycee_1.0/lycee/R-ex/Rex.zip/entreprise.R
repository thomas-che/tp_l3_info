### Encoding: ISO-8859-1

### Name: entreprise
### Title: entreprise/donn�es de type �conomique.
### Aliases: entreprise


### ** Examples

data(entreprise)
lire(entreprise)
histogramme(selection(ratio,etat,"S"))
ajustenormale(selection(ratio,etat,"S"))
mediane(selection(ratio,etat,"S"))
moyenne(selection(ratio,etat,"S"))

boitesparalleles(ratio,etat)




