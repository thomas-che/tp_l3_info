### Encoding: ISO-8859-1

### Name: tirage
### Title: Fonction qui tire al�atoirement un �chantillon dans une urne.
### Aliases: tirage


### ** Examples

u<-urne(100000,200000,40000)
t<-tirage(1000,u)
frequence(t)
frequence(u)




