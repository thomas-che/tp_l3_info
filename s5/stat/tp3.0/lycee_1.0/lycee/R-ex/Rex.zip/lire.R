### Encoding: ISO-8859-1

### Name: lire
### Title: Fonction qui lit des donn�es charg�es pr�alablement avec la
###   commande data.
### Aliases: lire


### ** Examples

data(bebe)
lire(bebe)
histogramme(long)



