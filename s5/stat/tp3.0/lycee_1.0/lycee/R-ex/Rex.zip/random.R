### Encoding: ISO-8859-1

### Name: random
### Title: Fonction qui donne un nombre au hasard dans un intervalle [a,b].
### Aliases: random


### ** Examples

r<-random(0,1)
if (r<0.5){piece="pile"} else {piece="face"}
piece

hist(r)
mediane(r)
moyenne(r)
variance(r)
ecarttype(r)




