### Name: kyste
### Title: diagnostique de kystes de l'ovaire/m�dical
### Aliases: kyste


### ** Examples

data(kyste)
lire(kyste)
boitesparalleles(oeakys,diagnostique)
nuagedepoints(ca125ser,prokys,couleur)



