### Encoding: ISO-8859-1

### Name: histogramme
### Title: Fonction qui trace l'histogramme
### Aliases: histogramme


### ** Examples


data(bebe)
lire(bebe)
moyenne(long)
histogramme(long)
ajustenormale(long)




