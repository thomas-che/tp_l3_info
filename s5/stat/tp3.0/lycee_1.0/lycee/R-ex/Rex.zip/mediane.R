### Encoding: ISO-8859-1

### Name: mediane
### Title: Fonction qui donne la m�diane d'une variable num�rique.
### Aliases: mediane


### ** Examples

d<-jeudedes(1000)
mediane(d)
data(guichet)
lire(guichet)
mediane(queue)



