### Encoding: ISO-8859-1

### Name: variance
### Title: Fonction qui donne la variance d'une variable num�rique.
### Aliases: variance


### ** Examples

data(bebe)
lire(bebe)
variance(long)





