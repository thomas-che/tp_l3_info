### Encoding: ISO-8859-1

### Name: pressionarterielle
### Title: pressionarterielle/donn�es de type m�dical.
### Aliases: pressionarterielle


### ** Examples

data(pressionarterielle)
lire(pressionarterielle)
histogramme(pression)
boitesparalleles(pression,fumeur)
histogramme(selection(pression,fumeur,"oui"))
moyenne(selection(pression,fumeur,"oui"))
ecarttype(selection(pression,fumeur,"oui"))
histogramme(selection(pression,fumeur,"non"))
moyenne(selection(pression,fumeur,"non"))
ecarttype(selection(pression,fumeur,"non"))




