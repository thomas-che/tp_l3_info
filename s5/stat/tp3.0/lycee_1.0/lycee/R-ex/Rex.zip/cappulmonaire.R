### Encoding: ISO-8859-1

### Name: cappulmonaire
### Title: cappulmonaire/donn�es de type m�dical
### Aliases: cappulmonaire


### ** Examples

data(cappulmonaire)
lire(cappulmonaire)
hist(capacite)
mediane(capacite)
moyenne(capacite)
ecarttype(capacite)
boitemoustache(capacite)



