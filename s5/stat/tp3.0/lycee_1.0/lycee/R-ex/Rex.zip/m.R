### Name: m
### Title: message cod�/texte
### Aliases: m


### ** Examples

data(m)
lire(m)



