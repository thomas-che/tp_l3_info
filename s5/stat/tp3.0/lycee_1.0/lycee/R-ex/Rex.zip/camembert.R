### Encoding: ISO-8859-1

### Name: camembert
### Title: Fonction qui trace le camembert ou diagramme en secteurs.
### Aliases: camembert


### ** Examples

d<-jeudedes(100)
camembert(d)
data(guichet)
lire(guichet)
camembert(queue)


