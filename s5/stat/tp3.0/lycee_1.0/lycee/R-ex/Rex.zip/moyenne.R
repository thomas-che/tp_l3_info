### Encoding: ISO-8859-1

### Name: moyenne
### Title: Fonction qui donne la moyenne arithm�tique d'une variable
###   num�rique.
### Aliases: moyenne


### ** Examples

data(entreprise)
lire(entreprise)
moyenne(ratio)



