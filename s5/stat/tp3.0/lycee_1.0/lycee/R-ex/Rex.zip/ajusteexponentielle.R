### Encoding: ISO-8859-1

### Name: ajusteexponentielle
### Title: Fonction qui trace l'histogramme et la densit� de la loi
###   exponentielle.
### Aliases: ajusteexponentielle


### ** Examples

data(robinet)
lire(robinet)
histogramme(consommation)
ajusteexponentielle(consommation)



