### Encoding: ISO-8859-1

### Name: lycee-package
### Title: Utilisation du logiciel R au coll�ge et au lyc�e
### Aliases: lycee-package lycee


### ** Examples
 d<-pileface(100)
 frequence(d)
diagrammeenbarre(d)
data(entreprise)
lire(entreprise)
histogramme(ratio)
boitesparalleles(ratio,etat)




