### Encoding: ISO-8859-1

### Name: loinormale
### Title: Function qui calcule, pour une variable qui suit une loi
###   normale,la probabilit� d'�tre inf�rieur � ou sup�rieur � un nombre.
### Aliases: loinormale


### ** Examples

loinormale(4,3,1)




