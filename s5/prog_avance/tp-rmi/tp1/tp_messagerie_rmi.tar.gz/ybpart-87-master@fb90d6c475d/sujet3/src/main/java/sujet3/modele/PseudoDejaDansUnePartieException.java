package sujet3.modele;

public class PseudoDejaDansUnePartieException extends Exception {
}
