package sujet3.modele;

public class PartieInexistanteException extends Throwable {
}
