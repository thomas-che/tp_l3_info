package sujet4.modele.exceptions;

public class DiscussionInexistanteException extends Exception {
}
