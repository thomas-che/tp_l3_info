package sujet4.modele.exceptions;

public class DestinataireInconnuException extends Exception {
}
