package sujet1online.modele.exceptions;

public class UtilisateurDejaExistantException extends Exception {
}
