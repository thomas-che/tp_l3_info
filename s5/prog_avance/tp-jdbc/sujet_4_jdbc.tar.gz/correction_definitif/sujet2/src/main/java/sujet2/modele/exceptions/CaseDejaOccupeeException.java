package sujet2.modele.exceptions;

public class CaseDejaOccupeeException extends Exception {
}
