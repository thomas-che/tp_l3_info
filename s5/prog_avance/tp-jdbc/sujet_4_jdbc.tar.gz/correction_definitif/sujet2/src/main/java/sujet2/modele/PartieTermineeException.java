package sujet2.modele;

public class PartieTermineeException extends Exception {
}
