package sujet2.modele.exceptions;

public class PartieNonTermineeException extends Exception {
}
