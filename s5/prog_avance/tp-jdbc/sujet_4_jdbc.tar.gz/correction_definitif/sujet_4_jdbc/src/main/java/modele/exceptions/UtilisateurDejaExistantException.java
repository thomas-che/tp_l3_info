package modele.exceptions;

public class UtilisateurDejaExistantException extends Exception {
}
