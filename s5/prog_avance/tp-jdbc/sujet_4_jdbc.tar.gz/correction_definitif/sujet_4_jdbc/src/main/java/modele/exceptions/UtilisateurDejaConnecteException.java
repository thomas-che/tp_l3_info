package modele.exceptions;

public class UtilisateurDejaConnecteException extends Exception {
}
