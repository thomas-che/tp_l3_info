package modele.exceptions;

public class DiscussionDejaExistanteException extends Exception {
}
