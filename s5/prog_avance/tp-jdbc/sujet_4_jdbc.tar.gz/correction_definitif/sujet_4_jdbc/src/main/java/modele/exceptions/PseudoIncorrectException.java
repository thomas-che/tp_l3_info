package modele.exceptions;

public class PseudoIncorrectException extends Exception {
}
