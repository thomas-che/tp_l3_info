package modele.exceptions;

public class DiscussionInexistanteException extends Exception {
}
