package modele.exceptions;

public class IdentifiantsIncorrectsException extends Exception {
}
