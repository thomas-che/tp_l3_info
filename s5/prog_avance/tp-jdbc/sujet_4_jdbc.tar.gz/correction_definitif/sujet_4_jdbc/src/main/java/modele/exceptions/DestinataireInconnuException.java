package modele.exceptions;

public class DestinataireInconnuException extends Exception {
}
