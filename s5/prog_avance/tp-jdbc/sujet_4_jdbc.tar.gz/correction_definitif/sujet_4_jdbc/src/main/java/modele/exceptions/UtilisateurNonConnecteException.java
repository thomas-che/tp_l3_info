package modele.exceptions;

public class UtilisateurNonConnecteException extends Exception {
}
