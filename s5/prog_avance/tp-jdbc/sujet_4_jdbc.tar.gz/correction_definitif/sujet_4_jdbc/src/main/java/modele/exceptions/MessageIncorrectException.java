package modele.exceptions;

public class MessageIncorrectException extends Exception {
}
