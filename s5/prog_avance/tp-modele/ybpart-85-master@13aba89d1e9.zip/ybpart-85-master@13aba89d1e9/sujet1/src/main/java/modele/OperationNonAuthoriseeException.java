package modele;

public class OperationNonAuthoriseeException extends Exception {
    public OperationNonAuthoriseeException(String message) {
        super(message);
    }
}
