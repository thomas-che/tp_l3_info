package modele;

public class DossierDejaExistantException extends Exception {
    public DossierDejaExistantException(String message) {
        super(message);
    }
}
