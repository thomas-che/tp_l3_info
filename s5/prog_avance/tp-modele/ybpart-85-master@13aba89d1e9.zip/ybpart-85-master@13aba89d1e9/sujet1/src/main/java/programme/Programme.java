package programme;

import modele.*;

import java.util.Collection;

public class Programme {

    public static void main(String[] args) {
        FacadeFileSystem facadeFileSystem =
                new FacadeFileSystem("/");

        try {
            facadeFileSystem.mkdir("dossier1");
            facadeFileSystem.mkdir("dossier2");

            System.out.println("------------------------------------");

            Collection<Composant> composants =
                    facadeFileSystem.ls();

            for (Composant c : composants) {
                System.out.println(c.getNom());
            }
            System.out.println("------------------------------------");
            facadeFileSystem.cd("dossier2");
            facadeFileSystem.mkdir("dossier3");

            composants =
                    facadeFileSystem.ls();
            System.out.println("------------------------------------");
            for (Composant c : composants) {
                System.out.println(c.getNom());
            }
            System.out.println("------------------------------------");

            facadeFileSystem.cd(Dossier.PARENT);
            composants =
                    facadeFileSystem.ls();
            System.out.println("------------------------------------");
            for (Composant c : composants) {
                System.out.println(c.getNom());
            }
            System.out.println("------------------------------------");

            facadeFileSystem.cd(Dossier.PARENT);

           // facadeFileSystem.mkdir("dossier2");
        } catch (DossierDejaExistantException | DossierInexistantException | OperationNonAuthoriseeException e) {
            System.err.println(e.getMessage());
        }

    }
}
