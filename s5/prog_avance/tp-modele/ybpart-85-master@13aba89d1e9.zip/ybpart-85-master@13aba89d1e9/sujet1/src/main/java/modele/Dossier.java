package modele;

import java.util.ArrayList;
import java.util.Collection;

public class Dossier implements Composant {
    public static final String PARENT = "..";
    private String nom;
    private Dossier dossierParent;
    private Collection<Dossier> dossiers;
    private Collection<Fichier> fichiers;

    public Dossier(Dossier dossierParent, String nom) {
        this.nom = nom;
        this.dossierParent = dossierParent;
        this.dossiers = new ArrayList<>();
        this.fichiers = new ArrayList<>();
    }

    @Override
    public String getNom() {
        return nom;
    }

    public void mkdir(String nomDossier)
            throws DossierDejaExistantException {
        for(Dossier d : this.dossiers) {
            if (d.getNom().equals(nomDossier))
                throw new DossierDejaExistantException(
                        "Le dossier "+nomDossier+" existe déjà !");
        }

        Dossier nouveau = new Dossier(this,nomDossier);
        this.dossiers.add(nouveau);

    }

    public Collection<Composant> ls() {
        Collection<Composant> resultat = new ArrayList<>();
        resultat.addAll(dossiers);
        resultat.addAll(fichiers);
        return resultat;
    }

    public Dossier cd(String nomDossier) throws DossierInexistantException {

        if (PARENT.equals(nomDossier)) {
            return dossierParent;
        }

        for (Dossier d : this.dossiers) {
            if (d.getNom().equals(nomDossier)) {
                return d;
            }
        }
        throw new DossierInexistantException(nomDossier + " n'existe pas");
    }
}
