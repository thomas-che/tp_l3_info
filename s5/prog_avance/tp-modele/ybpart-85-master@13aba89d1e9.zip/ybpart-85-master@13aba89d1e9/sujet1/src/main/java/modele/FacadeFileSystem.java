package modele;

import java.util.Collection;

public class FacadeFileSystem {
    private Dossier dossierCourant;
    private Dossier racine;


    public FacadeFileSystem(String nomRacine) {
        this.dossierCourant = new Dossier(null,nomRacine);
        this.racine = this.dossierCourant;
    }


    public void mkdir(String nomDossier)
            throws DossierDejaExistantException {

        this.dossierCourant.mkdir(nomDossier);
    }


    public Collection<Composant> ls() {
        return this.dossierCourant.ls();
    }


    public void cd(String nomDossier) throws DossierInexistantException, OperationNonAuthoriseeException {
        if (nomDossier.equals(Dossier.PARENT) &&
                this.dossierCourant == racine) {
            throw new OperationNonAuthoriseeException("cd .. impossible sur la racine !!");
        }
        this.dossierCourant = this.dossierCourant.cd(nomDossier);
    }

}
