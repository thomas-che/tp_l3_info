package modele;

public class Fichier implements Composant {
    private String nom;
    private String contenu;

    public Fichier(String nom, String contenu) {
        this.nom = nom;
        this.contenu = contenu;
    }

    public String getContenu() {
        return contenu;
    }

    @Override
    public String getNom() {
        return this.nom;
    }
}
