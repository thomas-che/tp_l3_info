package modele;

public class DossierInexistantException extends Exception {
    public DossierInexistantException(String message) {
        super(message);
    }
}
