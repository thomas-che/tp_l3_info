package sujet1.modele;

public interface Composant {
    String getNom();
}
