package sujet3.modele;

public class PasVotreTourException extends Exception {
}
