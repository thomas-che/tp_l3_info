package sujet4.modele.exceptions;

public class UtilisateurInexistantException extends Exception {
}
