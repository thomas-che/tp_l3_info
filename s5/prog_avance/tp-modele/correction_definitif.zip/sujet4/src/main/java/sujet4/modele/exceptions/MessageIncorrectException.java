package sujet4.modele.exceptions;

public class MessageIncorrectException extends Exception {
}
