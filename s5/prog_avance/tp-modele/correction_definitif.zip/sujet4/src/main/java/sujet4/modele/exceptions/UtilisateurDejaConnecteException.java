package sujet4.modele.exceptions;

public class UtilisateurDejaConnecteException extends Exception {
}
