package sujet4.modele.exceptions;

public class DiscussionDejaExistanteException extends Exception {
}
