package sujet4.modele.exceptions;

public class UtilisateurDejaExistantException extends Exception {
}
