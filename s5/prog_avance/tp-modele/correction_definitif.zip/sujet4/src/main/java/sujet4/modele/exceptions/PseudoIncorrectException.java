package sujet4.modele.exceptions;

public class PseudoIncorrectException extends Exception {
}
