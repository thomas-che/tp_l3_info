package sujet4.modele.exceptions;

public class UtilisateurNonConnecteException extends Exception {
}
