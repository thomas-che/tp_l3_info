package sujet4.modele.exceptions;

public class IdentifiantsIncorrectsException extends Exception {
}
