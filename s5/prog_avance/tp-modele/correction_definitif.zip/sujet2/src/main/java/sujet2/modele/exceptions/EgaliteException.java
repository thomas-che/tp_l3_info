package sujet2.modele.exceptions;

public class EgaliteException extends Exception {
}
