package sujet2.modele.exceptions;

public class PseudoIncorrectException extends Exception {
}
