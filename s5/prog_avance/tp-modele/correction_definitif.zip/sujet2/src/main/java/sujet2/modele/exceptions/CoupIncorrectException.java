package sujet2.modele.exceptions;

public class CoupIncorrectException extends Exception {
}
