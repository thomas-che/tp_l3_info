package exceptions;

public class PseudoDejaUtiliseException extends Exception {
}
