package exceptions;

public class PasDeGagnantException extends Exception {
}
