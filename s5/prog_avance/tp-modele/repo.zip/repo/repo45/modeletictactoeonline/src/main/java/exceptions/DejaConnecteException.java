package exceptions;

public class DejaConnecteException extends Exception {
}
