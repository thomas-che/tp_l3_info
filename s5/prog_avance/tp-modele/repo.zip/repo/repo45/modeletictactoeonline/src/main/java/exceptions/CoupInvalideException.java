package exceptions;

public class CoupInvalideException extends Exception {
}
