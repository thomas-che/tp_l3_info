package exceptions;

public class PseudosIncorrectsException extends Exception {
}
