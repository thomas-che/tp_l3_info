package exceptions;

public class CoupDejaJoueException extends Exception {
}
