package exceptions;

public class TricheurException extends Exception {
}
