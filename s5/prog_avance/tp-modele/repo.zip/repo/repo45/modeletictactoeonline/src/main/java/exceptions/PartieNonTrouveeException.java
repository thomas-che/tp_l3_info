package exceptions;

public class PartieNonTrouveeException extends Exception {
}
