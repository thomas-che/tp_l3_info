package modele;

public interface Coup {
    static Coup nouveauCoup(int x, int y) {
        return null;
    }
}
