package modele;

public class CoupInvalideException extends Exception {
}
