package modele;

public class PseudosIncorrectsException extends Exception {
}
