package modele;

public class PasDeGagnantException extends Exception {
}
