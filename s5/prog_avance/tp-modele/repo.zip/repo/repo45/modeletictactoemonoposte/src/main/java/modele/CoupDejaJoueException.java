package modele;

public class CoupDejaJoueException extends Exception {
}
