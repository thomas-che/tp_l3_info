package modele;

public class TricheurException extends Exception {
}
