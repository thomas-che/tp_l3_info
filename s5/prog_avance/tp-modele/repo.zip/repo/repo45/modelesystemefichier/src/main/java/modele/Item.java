package modele;

public interface Item {


    String getNom();

    void setNom(String nomFutur);

    String getInfo();
}
