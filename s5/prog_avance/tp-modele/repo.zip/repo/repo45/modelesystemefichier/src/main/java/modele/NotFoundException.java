package modele;

public class NotFoundException extends Exception {
}
