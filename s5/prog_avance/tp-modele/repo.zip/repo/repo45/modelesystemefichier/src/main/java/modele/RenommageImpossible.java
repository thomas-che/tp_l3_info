package modele;

public class RenommageImpossible extends Exception {
}
