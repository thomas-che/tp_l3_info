package modele;

public class DejaPresentException extends Exception {
}
