package exceptions;

public class OperationNonAuthoriseeException extends Exception {
}
