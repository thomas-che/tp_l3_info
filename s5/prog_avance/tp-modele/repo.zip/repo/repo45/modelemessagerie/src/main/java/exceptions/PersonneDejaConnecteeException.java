package exceptions;

public class PersonneDejaConnecteeException extends Throwable {
}
