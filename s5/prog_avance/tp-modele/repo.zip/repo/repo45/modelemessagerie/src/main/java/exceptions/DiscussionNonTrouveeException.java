package exceptions;

public class DiscussionNonTrouveeException extends Exception {
}
