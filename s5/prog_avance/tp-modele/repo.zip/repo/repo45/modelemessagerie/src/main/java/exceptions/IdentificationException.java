package exceptions;

public class IdentificationException extends Exception {
}
