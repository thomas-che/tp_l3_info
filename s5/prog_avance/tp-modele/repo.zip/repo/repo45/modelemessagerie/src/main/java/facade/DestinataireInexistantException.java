package facade;

public class DestinataireInexistantException extends Exception {
}
