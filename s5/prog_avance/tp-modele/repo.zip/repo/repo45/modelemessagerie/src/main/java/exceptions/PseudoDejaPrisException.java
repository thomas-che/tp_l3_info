package exceptions;

public class PseudoDejaPrisException extends Exception {
}
