package exceptions;

public class MauvaisFormatDonneesException extends Throwable {
}
