package modele.exceptions;

public class EgaliteException extends Exception {
}
