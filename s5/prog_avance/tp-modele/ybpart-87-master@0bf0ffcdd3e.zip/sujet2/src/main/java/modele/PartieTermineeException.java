package modele;

public class PartieTermineeException extends Exception {
}
