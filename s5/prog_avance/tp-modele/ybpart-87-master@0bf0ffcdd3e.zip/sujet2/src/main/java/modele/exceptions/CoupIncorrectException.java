package modele.exceptions;

public class CoupIncorrectException extends Exception {
}
