package modele.exceptions;

public class PartieNonTermineeException extends Exception {
}
