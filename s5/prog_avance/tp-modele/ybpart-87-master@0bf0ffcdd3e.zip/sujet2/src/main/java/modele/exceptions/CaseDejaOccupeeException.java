package modele.exceptions;

public class CaseDejaOccupeeException extends Exception {
}
