package facade;

public class PseudoDejaDansUnePartieException extends Exception {
}
