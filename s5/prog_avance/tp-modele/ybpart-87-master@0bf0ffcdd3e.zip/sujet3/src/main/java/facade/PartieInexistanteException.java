package facade;

public class PartieInexistanteException extends Throwable {
}
