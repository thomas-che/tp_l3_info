package facade;

public class PasVotreTourException extends Exception {
}
