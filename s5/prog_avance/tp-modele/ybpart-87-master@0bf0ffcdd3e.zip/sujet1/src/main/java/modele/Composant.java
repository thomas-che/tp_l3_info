package modele;

public interface Composant {
    String getNom();
}
